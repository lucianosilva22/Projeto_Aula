'''
Primeiro Projeto - (BlackJack)
**1° Passo** - Entender o jogo.

Em um jogo de BlackJack são usadas as 52 cartas do baralho, dividas por naipes sendo eles (Espadas, Copas, Ouros, Paus). As cartas seguem o seguinte padrão:

*   A
*   K (Rei)
*   J (Valete)
*   Q (Rainha)
*   2
*   3
*   4
*   5
*   6
*   7
*   8
*   9
*   10

Todas elas tendo os 4 naipes possíveis. E sendo possível usar mais de um baralho por jogo.

**Regras**

*   Todas cartas valem o seu valor, exceto o A,K,J,Q, que valem, respectivamente 1 ou 11(escolha do jogador), 10, 10, 10.
*   O jogador e o croupier(distribuidor das cartas) são os que protagonizam o jogo. O que fizer a maior pontuação, sem ultrapassar os 21 pontos, será o vencedor. Caso o jogador ou croupier ultrapasse os 21, o mesmo perderá automaticamente. Já quando se chega a 21 pontos o jogo acaba e quem conseguiu os 21 pontos ganha, em caso dos dois atingirem a marca há um empate.
*   Um BlackJack é quando o jogador recebe um A's e um carta com valor 10.
*   O croupier só pode pedir até um máximo de 5 cartas ou até chegar ao número 17.

**Rodada**

* A rodada começa com o jogador colocando uma aposta na mesa.
* O croupier dá à cada jogador e a si mesmo duas cartas, as cartas do croupier são, respectivamente uma visível e uma não, já as dos jogadores são visíveis.
* Apos isso o jogador escolhe pedir mais cartas ou parar
* Depois de todos jogarem é a vez do croupier, ele pode pedir cartas ate atigir 17 pontos
* Quem tiver uma mão maior que a do croupier (sem passar de 21) ganha. Se o croupier estourar (passar de 21), todos os jogadores que ainda estão no jogo ganham.

**Opções de jogo**

Quando chegar a sua vez, você terá algumas opções principais para escolher:
* Pedir (Hit): Você pede mais uma carta ao croupier para tentar aumentar sua pontuação. Você pode pedir quantas cartas quiser, desde que não passe de 21.
* Parar (Stand): Você escolhe ficar com as cartas que já tem e encerrar sua jogada.
* Dobrar (Double Down): Se você achar que tem uma mão muito forte, pode dobrar o valor da sua aposta inicial. Em troca, você recebe exatamente mais uma carta e sua vez termina.
* Dividir (Split): Se as suas duas primeiras cartas forem de igual valor (por exemplo, dois 8s ou dois Valetes), você pode separá-las em duas mãos independentes. Você faz uma nova aposta de mesmo valor para a segunda mão e joga cada uma delas separadamente.


**2º Passo** - Estruturar a logica

**3° Passo** - Montar o Código
'''

from funcoes_blackjack import calcular_pontuacao, playerturn, result
import random
baralho = {'A' : 11,
           'K' : 10,
           'Q' : 10,
           'J' : 10,
           '2' : 2,
           '3' : 3,
           '4' : 4,
           '5' : 5,
           '6' : 6,
           '7' : 7,
           '8' : 8,
           '9' : 9,
           '10' : 10}
menu = '''
VER SALDO.[S]
PARAR.....[P]
JOGAR.....[J]
'''
saldo = 300

while True:
  estouro = False
  parar = False
  blackjack = False
  print(menu)
  opcao = input('Digite uma opção [S/P/J/M]: ').strip().lower()

  if opcao == 'j':

    if saldo == 0 or saldo < 30:
        print('Saldo Zerado. Ou Insuficiente\n')
        break
    try:
      aposta = float(input('Quanto deseja apostar: '))
    except ValueError:
      print('Dígito Inválido!\n')
      continue

    if aposta < 30:
      print('Somente apostas maiores que 30R$.\n')
      continue

    if aposta > saldo:
      print('Saldo Insuficiente.')
      continue

    # TODO: AQUI COMEÇA O JOGO
    if aposta <= saldo and aposta >= 30:
      saldo -= aposta
      cartas = list(baralho)

      cartas_jogador = random.choices(cartas, k=2)
      cartas_croupier = [random.choice(cartas)]

      # TODO: MOSTRA A CARTA DO CROUPIER
      print(f"\n{cartas_croupier[0]} - Carta Virada\n\n\n\n")

      # TODO: SOMA AS CARTAS DO JOGADOR E AS CARTAS DO CROUPIER(QUE NO MOMENTO É UMA SÓ)
      soma_jogador = calcular_pontuacao(baralho,cartas_jogador)
      soma_croupier = calcular_pontuacao(baralho,cartas_croupier)

      # TODO: MOSTRA O SEU BARALHO
      print('Seu Baralho\n')
      print(f"{cartas_jogador}\n")
      print(f'Sua pontução é: {soma_jogador}\n')

      # TODO: VERIFICA ANTES DE TUDO SE O JOGADOR JA ATINGIU O BLACKJACK
      if soma_jogador == 21:
        blackjack = True
        print('BlackJack!\n')

      while soma_jogador < 21:
        opcao = input('Parar[P] | Pedir(Hit)[H]: ').lower().strip()
        if opcao == 'p':
          print(f'Parou! Sua pontuação foi: {soma_jogador}\n')
          parar = True
          break

        elif opcao == 'h':
          playerturn(baralho,cartas_jogador)

          print('Seu Baralho\n')
          print(cartas_jogador)

          soma_jogador = calcular_pontuacao(baralho,cartas_jogador)

          print(f'Sua pontução é {soma_jogador}.\n')

        else:
          print('Opção Inválida!\n')

        if soma_jogador == 21:
          print('BlackJack!\n')
          blackjack = True

        if soma_jogador > 21:
          print('Estourou!\n')
          print('Casa Vence!\n')
          estouro = True
          break

        if estouro:
          continue

      # TODO: AQUI COMEÇA A VEZ D CROUPIER
      if parar == True or blackjack == True:
        carta_um_croupier = baralho[cartas_croupier[0]]
        soma_croupier = calcular_pontuacao(baralho,cartas_croupier)

        print('Vez do Croupier!\n')
        print(f"{cartas_croupier}\n")
        print(f'Pontuação Croupier: {soma_croupier}\n')

      while soma_croupier < 17:
        playerturn(baralho,cartas_croupier)
        soma_croupier = calcular_pontuacao(baralho,cartas_croupier)

        print('Baralho Croupier\n')
        print(cartas_croupier)

      print('Croupier atingiu o limite!\n')
      print(f"A pontução do croupier foi: {soma_croupier}\n")

      # TODO: RESULTADO SAI AQUI
      result(soma_jogador, soma_croupier, saldo, aposta)

    else:
      print('Saldo Insuficiente!\n\n')

  elif opcao == 's':
    print(f'Seu saldo é: {saldo}\n')

  elif opcao == 'p':
    print('Jogo Encerrado!\n')
    break

  elif opcao == 'm':
    print(menu)

  else:
    print('Opção Inválida!\n')